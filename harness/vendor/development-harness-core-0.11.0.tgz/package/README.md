# Development Harness Core

Product-neutral runtime for one fixed deterministic thirteen-stage development
workflow with typed project adapters. It is not a general workflow engine.

The package owns lifecycle state, artifacts, role relay, Gate orchestration,
file locking, metrics, archive behavior, and the parameterized CLI. It does not
own project paths, commands, Skills, package owners, Gate catalogs, branch
policies, or product verification.

Every RoleTask receives an immutable copy of the adapter-declared project Rules
in its inbox. The Rules digest participates in the input manifest, while
project-selected Skills remain task-specific operating manuals.

Role execution is serial and short-lived. The Controller creates one immutable
inbox, invokes the current cognitive role once, collects its outbox, and closes
that execution context. The Core does not require persistent role windows,
cross-turn mailboxes, or a Team lifecycle.

Initialization requires a structured `development_harness.admission.v6`
artifact in addition to the raw request. The record binds the request digest,
exact Git base, content-digested project evidence, unresolved semantic delta,
one independently reversible Initiative slice, exact repository owners,
patterned feasibility evidence, exclusions, classification, and one or more
adapter-resolved product Capability IDs and semantic-host claims. Each claim
binds stable privileged-responsibility IDs to one host, and each delivery unit
names the exact admitted responsibilities it changes. Core rejects duplicate
hosts for one responsibility and verifies the host module, owning contract,
exact Git base, and admitted Capability ownership. It also proves why the thirteen-stage
relay is needed: a product request or operational incident must retain at
least one bounded human authority decision and at least two owner-bound
delivery units with one common acceptance boundary. Every admitted owner must
own a declared unit.
Core refuses `init` unless the request, Git base, and safe project-relative
evidence match, the classification is `harness_initiative`, and the existing
capability verdict is `missing` or `partial`. Reference-parity investigations
and repository maintenance are rejected; they use Discovery or Direct SDD
until a separate product outcome is frozen. Unknown owners, contracts,
lifecycle, recovery, semantic host, or product paths route to pre-Initiative Architecture
Discovery rather than entering the workflow. Stage 2 receives both immutable
request/admission inputs plus a controller-generated Capability and semantic-host baseline. Stages
5, 7, 9, and 11 receive the same Admission and baseline so exact host and
responsibility claims survive design, implementation, and both independent
reviews instead of being inferred again from repository layout. The
baseline freezes each Capability's identity, owner-document digest, and
four-axis maturity, plus each host module, owning document, and privileged
responsibility identities and categories at admission. New Requirement and Impact Map artifacts use
their v3 schemas and must exactly retain the admitted Capability and owner IDs.
Requirement completeness is the sum of five evidence-backed dimensions, while
the independent `ready`, `discovery_required`, or `split_required` disposition
controls progression. Core
accepts only the current capability-traceable schemas; older Initiative
artifacts are not migrated or resumed.

Stage 13 accepts `development_harness.delivery_draft.v2`. It records an empty
Capability delta only when the adapter observes no maturity change; otherwise
it requires exact baseline/current maturity and the complete current acceptance
Gate receipt set before closing delivery.

Version 0.11 writes `development_harness.lean.v3` state and uses
`development_harness.project_adapter.v3`. Archived v2 checkpoints remain
readable for metrics and archive inspection, but cannot resume. The adapter
must resolve stable Capability IDs to an owning document and current four-axis
maturity, and semantic-host IDs from project-frozen facts rather than path
inference.

The thirteen stages are stable lifecycle milestones, not a universal checklist.
Already-frozen source-parity gaps, bounded bugs, and one atomic semantic
transaction use Direct SDD even when they touch several packages or carry high
risk. Patterned Harness is reserved for the requirement-to-delivery relay
described by admission v6.

Stage 8 freezes the exact workspace and executes only Gates whose adapter
definition explicitly applies to baseline. Owner tests, typechecks, and product
paths normally apply at Stage 10. Stage 12 reuses a passing Stage 10 receipt
when the complete implementation delta and environment match, so an unchanged
Gate is not executed twice.

```bash
pnpm harness -- init \
  --project . \
  --id <initiative> \
  --controller-thread <controller> \
  --git-base <sha> \
  --admission <admission.json> \
  --request <request.md>
```

Design and TaskPlan artifacts use exact acceptance IDs, repository owners,
deliverables, and write paths. Design also projects every admitted delivery
unit to its exact semantic host, responsibility IDs, and authoritative entry
point. A migration Impact requires a bounded transition contract with exact
paths, canonical host module, allowed consumers, retirement condition, and
old-path negative oracle; initiatives without migration impacts use an empty
transition set. TaskPlan assigns every transition to exactly one owner task.
Before design review the Core deterministically
rejects uncovered acceptance, unowned deliverables, cross-owner tasks, duplicate
writes, unsafe paths, owner-set drift, semantic-binding drift, uncovered or
duplicate transitions, and adapter-declared broad test Gates that lack a
structured selection reason. At implementation collection, Core requires
delivery-unit authority evidence to preserve the frozen host, responsibilities,
and entry point. Each evidence claim must bind a TaskPlan-selected hard Gate
that executes after implementation. Core likewise requires executed
negative-oracle evidence and its hard Gate for every transition. A blocking
review is one atomic finding batch: every finding is
retained and relayed together on rollback.
The Stage 10 Integration Result projects the complete current Gate receipts,
including gate identity, command, enforcement, exit status, fingerprints, and
evidence path, into the Stage 11 inbox so the independent Reviewer can verify
the evidence binding without reading Controller state.

Automatic rollback still follows finding ownership. When a hard Gate exposes a
mistaken TaskPlan rather than an implementation defect, an operator may select
an earlier rollback target only when that target is declared by the current
Stage and the command binds both an authority and a reason:

```bash
pnpm harness -- rollback \
  --id <initiative> \
  --target 5 \
  --authority user \
  --reason "The selected broad Gate does not match the frozen owner boundary."
```

Bug reproduction and design confirmation run only when the Requirement
explicitly marks them applicable; their stage numbers remain stable when
skipped. Stage 3 persists the controller-owned, digest-bound human decision as
an artifact consumed by the Architect and both Reviewer passes. Conditional
Stage 4 freezes the observable difference through an entry point, command,
expected outcome, observed outcome, exit code, and fingerprint. A `testPath`
is optional because reproduction can precede regression-test authoring; when
present it must name an existing safe project-relative file. Design
confirmation is bound once to the confirmed requirement and impact map.
Technical corrections for that same boundary return directly to review. A
three-cycle circuit breaker cannot authorize an unchanged retry; it requires
requirement re-scoping or cancellation.

Metrics derive a finite correction-cause breakdown from checkpoint facts:
admission re-scope, requirement boundary, deterministic contract, semantic
review, role execution, implementation defect, new Gate failure, environment,
and human revision. Agents and operators cannot self-report or reinterpret the
classification.

## Adapter boundary

Consumers provide a validated `development_harness.project_adapter.v3`.
Adapter validation occurs before state access. Commands are fixed argv arrays
and execute without a shell.

```ts
import { runHarnessCli, type ProjectAdapter } from "@development-harness/core";

declare const adapter: ProjectAdapter;
await runHarnessCli(["list", "--project", process.cwd()], adapter);
```

## Development

```bash
pnpm install
pnpm check
```

`dist/` is committed so a Git-pinned local consumer can execute the package
without relying on machine-local build residue. `pnpm check` rebuilds it and
fails when the committed distribution is stale or contains untracked output,
then packs and imports the exact publishable archive.

`src/fixtures/sample-project-adapter.ts` demonstrates a consumer with distinct
state, navigation, Skill, owner, Gate, command, and branch conventions.
